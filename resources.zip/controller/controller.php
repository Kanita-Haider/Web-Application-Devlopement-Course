<?php

include('config.php');

class Controller {
	public $name=NAME;
	public $host=HOST;
	public $user=USER;
	public $pass=PASSWORD;
	

	public $conn;
	public $error;

	
	function __construct(){
		$this->conn=new mysqli($this->host,$this->user,$this->pass,$this->name);
		if(!$this->conn){
			$this->error ="connection failed".$this->conn->connect_error;
			return false; 
		}
	}

	function store($sufian){
		$niloy=$this->conn->query($sufian) or die($this->conn->error.__LINE__);

		if ($niloy) {
			header("Location: ../index.php.php?msg=".urldecode("Data Store Successfully"));
		}
		else{
			header("Location: ../registation.php?error=".urldecode("Data Store Failed"));
		}
	}

	

}