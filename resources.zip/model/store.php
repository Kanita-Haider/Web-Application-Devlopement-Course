<?php
include ('../controller/controller.php');
$controller=new controller;

if ($_SERVER['REQUEST_METHOD']=="POST") {
	
	// var_dump($_FILES['image']);

	$name=$_POST['name'];
	$email=$_POST['email'];

	$image_name=$_FILES['image']['name'];
	$_FILES['image']['type'];
	$image_location=$_FILES['image']['tmp_name'];
	$_FILES['image']['size'];

	$chayan=explode('.', $image_name);
	$new_image=round(microtime(true)).'.'.end($chayan);

	$move=move_uploaded_file($image_location, "../resources/images/".$new_image);

	if ($move) {
		$sql="INSERT INTO `image`(`name`, `email`, `image`) VALUES ('$name','$email','$new_image')";
		$controller->store($sql);
	}
}